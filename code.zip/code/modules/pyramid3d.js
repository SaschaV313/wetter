/*
 Highcharts JS v8.0.0 (2019-12-10)

 Highcharts 3D funnel module

 (c) 2010-2019 Kacper Madej

 License: www.highcharts.com/license
*/
(function(a){"object"===typeof module&&module.exports?(a["default"]=a,module.exports=a):"function"===typeof define&&define.amd?define("highcharts/modules/pyramid3d",["highcharts","highcharts/highcharts-3d","highcharts/modules/cylinder","highcharts/modules/funnel3d"],function(b){a(b);a.Highcharts=b;return a}):a("undefined"!==typeof Highcharts?Highcharts:void 0)})(function(a){function b(a,b,c,d){a.hasOwnProperty(b)||(a[b]=d.apply(null,c))}a=a?a._modules:{};b(a,"modules/pyramid3d.src.js",[a["parts/Globals.js"]],
function(a){a=a.seriesType;a("pyramid3d","funnel3d",{reversed:!0,neckHeight:0,neckWidth:0,dataLabels:{verticalAlign:"top"}});""});b(a,"masters/modules/pyramid3d.src.js",[],function(){})});
//# sourceMappingURL=pyramid3d.js.map