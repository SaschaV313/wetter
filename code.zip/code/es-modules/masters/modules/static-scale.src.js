/**
 * @license Highcharts Gantt JS v8.0.0 (2019-12-10)
 * @module highcharts/modules/static-scale
 * @requires highcharts
 *
 * StaticScale
 *
 * (c) 2016-2019 Torstein Honsi, Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/static-scale.src.js';
